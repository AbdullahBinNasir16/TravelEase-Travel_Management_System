create database TravelEase2
use TravelEase2


-- TourOperator Table
CREATE TABLE TourOperator (
    operator_id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(50),
    phone VARCHAR(15),
    description TEXT,
    status VARCHAR(20)
);
ALTER TABLE TourOperator
ALTER COLUMN phone VARCHAR(100);


-- Admin Table
CREATE TABLE Admin (
    admin_id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(50),
    role VARCHAR(50)
);


-- Trip Table
CREATE TABLE Trip (
    trip_id INT IDENTITY (1,1) PRIMARY KEY,
    operator_id INT,
    title VARCHAR(100),
    description TEXT,
    location VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2),
    duration INT,
    capacity INT,
    start_date DATE,
    end_date DATE,
    notes TEXT,
    rating INT,
    status VARCHAR(20),
    FOREIGN KEY (operator_id) REFERENCES TourOperator(operator_id)
);
alter table Trip
drop constraint FK__Trip__operator_i__4D94879B

-- Booking Table
CREATE TABLE Booking (
    booking_id INT IDENTITY(1,1) PRIMARY KEY,
    trip_id INT,
    traveler_id INT,
    booking_date DATE,
    travelers_count INT,
    total_cost DECIMAL(10,2),
    status VARCHAR(20),
    FOREIGN KEY (trip_id) REFERENCES Trip(trip_id)

);
alter table Booking
add FOREIGN KEY (traveler_id) REFERENCES Users(Id)
--ALTER TABLE Booking DROP CONSTRAINT FK__Booking__trip_id__5070F446;


-- Payment Table
CREATE TABLE Payment (
    payment_id INT IDENTITY(1,1) PRIMARY KEY,
    booking_id INT,
    amount DECIMAL(10,2),
    payment_date DATE,
    method VARCHAR(50),
    status VARCHAR(20),
    FOREIGN KEY (booking_id) REFERENCES Booking(booking_id)
);
alter table Payment
drop column is_refunded, is_fraud

-- Users Table
CREATE TABLE Users (
    Id INT PRIMARY KEY IDENTITY(1,1),
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    Email VARCHAR(255),
    Password VARCHAR(255),
    Gender VARCHAR(255),
    DateOfBirth DATE
);


-- Wishlist Table
CREATE TABLE Wishlist (
    wishlist_id INT IDENTITY(1,1) PRIMARY KEY,
    traveler_id INT,
    trip_id INT,
	FOREIGN KEY (traveler_id) REFERENCES Users(Id),
    FOREIGN KEY (trip_id) REFERENCES Trip(trip_id)
);

INSERT INTO Admin (admin_id, name, email, password, role) VALUES
(1, 'Sandra Martinez', 'mayeradam@hotmail.com', '2)pRr0IN)r', 'Manager'),
(2, 'Ryan Lane', 'darius06@gmail.com', 'EM)D4O*nhe', 'SuperAdmin'),
(3, 'Alexandria Scott PhD', 'kayla00@lopez.biz', '%HtYWQb786', 'Manager'),
(4, 'Joshua Stevens', 'matthew40@hotmail.com', '_8bTXvuEDU', 'Support'),
(5, 'Jacqueline Chaney', 'michael91@hotmail.com', '@PTm+Ky_Q2', 'Support'),
(6, 'Robert White', 'cmitchell@butler-fields.com', 'sB0Je^j(+I', 'Support'),
(7, 'Sean Smith', 'deleonbryan@hotmail.com', ')AhIQUycs4', 'Manager'),
(8, 'James Henson', 'oriley@morrow.com', '5&4h0MiyN(', 'SuperAdmin'),
(9, 'Jacqueline Reyes', 'tonymurray@gmail.com', 'v_o2Gaw^&+', 'SuperAdmin'),
(10, 'Brian Jackson', 'xhale@nelson.com', '0u@Tdee&#u', 'Support'),
(11, 'Virginia Jimenez', 'matagabriela@gmail.com', '#4PuQmyP#y', 'Manager'),
(12, 'Miguel Williams', 'george19@huff.com', '@bDNsJv%q9', 'Support'),
(13, 'Patricia Kennedy', 'bscott@yahoo.com', '7G^1oHeFNo', 'Support'),
(14, 'Donna Potter', 'perkinsnina@williams.net', '#fh7*Q9r#W', 'Support'),
(15, 'Trevor Dillon', 'xanderson@yahoo.com', 'z@2HfvJSp@', 'Manager'),
(16, 'Margaret Gregory', 'zlane@yahoo.com', 'TITOvpu2&7', 'Support'),
(17, 'Willie Welch', 'robert94@gmail.com', ')0C6_wQw4M', 'SuperAdmin'),
(18, 'Janice Barber', 'troy03@yahoo.com', '@pc66Wc6#5', 'SuperAdmin'),
(19, 'Olivia Allen', 'patrick43@coleman-stevens.biz', '6@0Rnzoq!N', 'SuperAdmin'),
(20, 'Lindsey Davis', 'garnerstephen@gmail.com', 'MVX2DUqd&Y', 'Support'),
(21, 'Ryan Gutierrez', 'lauragriffin@gmail.com', '_YXHi_pf89', 'Support'),
(22, 'Brittany Hill', 'clarkdaisy@hotmail.com', '6!OOWv_I!+', 'Support'),
(23, 'Kelsey Hoffman', 'jenniferlarsen@stewart-thomas.net', 'Mlu^0GvM8X', 'SuperAdmin'),
(24, 'William Lewis', 'abigailfriedman@hotmail.com', '**%bOe8p0K', 'Manager'),
(25, 'Robert Barber', 'harry23@brennan-lawrence.com', '@8_9LRdBH(', 'SuperAdmin'),
(26, 'Jessica Curtis', 'espinozasteven@hotmail.com', 'ENu^S9Zx@7', 'SuperAdmin'),
(27, 'Stephen Arnold', 'taratate@gmail.com', ')1y&15Yk4g', 'Manager'),
(28, 'Dean Poole', 'duncanleonard@hotmail.com', '(82Bip5&*B', 'Manager'),
(29, 'Aaron Henderson', 'tgardner@yahoo.com', 'g_4YQPoV8t', 'Manager'),
(30, 'Mary Mathis', 'umcdonald@gmail.com', '_N5Z+M7c@$', 'Support'),
(31, 'Rachel Jackson', 'fharvey@cole.net', '%hw26KfZjl', 'Support'),
(32, 'John Watts', 'amber65@yoder-torres.com', 'd0Kh7DmO%U', 'SuperAdmin'),
(33, 'Roger Baldwin', 'sheri14@yahoo.com', '22UW_Sxn+x', 'SuperAdmin'),
(34, 'Kara Fisher', 'iwarren@black.com', '*cL66Wdma2', 'Manager'),
(35, 'Brian Johns', 'sarahlambert@yahoo.com', '3+BC0Scw(u', 'Manager'),
(36, 'Sydney Lewis', 'shermanaustin@aguilar.com', '@tP!Ynkzk3', 'Support'),
(37, 'Troy Jones', 'jeanette26@hotmail.com', 'i$QeEB(c@0', 'SuperAdmin'),
(38, 'Ethan Henson', 'tina59@yahoo.com', 'HK^bp2Rz$4', 'Manager'),
(39, 'Brian Allen', 'bartletttyler@hotmail.com', 'x#6U%2bhpQ', 'Support'),
(40, 'Jennifer Oliver', 'yhayes@hotmail.com', '_kUahwvaU0', 'SuperAdmin'),
(41, 'Steven Jackson', 'stephendavis@macias.net', '&65TzgPMub', 'SuperAdmin'),
(42, 'Kimberly Cardenas', 'crossdanielle@gmail.com', 'Ah5Cry_v#G', 'Manager'),
(43, 'Oscar Myers', 'gutierrezandrew@clarke.net', 's#&c8Sb^rf', 'Manager'),
(44, 'Leah Morales', 'martinalicia@daugherty-smith.com', 'b#84Lr^org', 'Manager'),
(45, 'Amanda Ibarra', 'roger02@baker.com', '$w(NGzg8O3', 'Support'),
(46, 'Steven White', 'brobinson@gmail.com', '@OX33gNu5t', 'Support'),
(47, 'Amber Yang', 'mauriceschmidt@gilbert.com', '6D_14cLuF)', 'Manager'),
(48, 'Carl Moore', 'willie93@yahoo.com', '235eX*us+S', 'Support'),
(49, 'Amy Mendoza', 'tcook@curry-reeves.info', '&e8U4*tPs(', 'Manager'),
(50, 'Martin Burton', 'dylan24@perez-hunt.com', '&l76TLuh02', 'Manager');
