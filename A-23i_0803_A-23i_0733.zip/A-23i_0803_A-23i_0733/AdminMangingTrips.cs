﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AdminMangingTrips : Form
    {
        public AdminMangingTrips()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int tripId;
            if (!int.TryParse(textBox3.Text, out tripId))
            {
                MessageBox.Show("Please enter a valid Trip ID to delete.");
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this trip?",
                                                  "Confirm Deletion",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";
                string query = "DELETE FROM Trip WHERE trip_id = @trip_id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@trip_id", tripId);
                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        conn.Close();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Trip deleted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Trip ID not found.");
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int tripId;
            if (!int.TryParse(textBox3.Text, out tripId))
            {
                MessageBox.Show("Invalid Trip ID");
                return;
            }

            string description = textBox1.Text;
            decimal price;
            if (!decimal.TryParse(textBox5.Text, out price))
            {
                MessageBox.Show("Invalid price format");
                return;
            }

            DateTime startDate, endDate;
            if (!DateTime.TryParse(dateTimePicker2.Text, out startDate) || !DateTime.TryParse(dateTimePicker1.Text, out endDate))
            {
                MessageBox.Show("Invalid date format");
                return;
            }

            string notes = textBox9.Text;
            string status = textBox10.Text;

            string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";

            string query = @"UPDATE Trip 
                     SET description = @description, 
                         price = @price, 
                         start_date = @start_date, 
                         end_date = @end_date, 
                         notes = @notes, 
                         status = @status
                     WHERE trip_id = @trip_id";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@description", description);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@start_date", startDate);
                    cmd.Parameters.AddWithValue("@end_date", endDate);
                    cmd.Parameters.AddWithValue("@notes", notes);
                    cmd.Parameters.AddWithValue("@status", status);
                    cmd.Parameters.AddWithValue("@trip_id", tripId);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Trip updated successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Trip ID not found.");
                    }
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
