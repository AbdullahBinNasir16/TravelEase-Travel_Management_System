﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class TravellerDashboard : Form
    {
        public TravellerDashboard()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            TripListing tripListing = new TripListing();
            this.Hide();
            tripListing.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Booking booking = new Booking();
            this.Hide();
            booking.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Wishlist wishlist = new Wishlist();
            this.Hide();
            wishlist.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Payment payment = new Payment();
            this.Hide();
            payment.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }
    }
}
