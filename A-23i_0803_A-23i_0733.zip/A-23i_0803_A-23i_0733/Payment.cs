﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Payment successful!");
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TravellerDashboard tripDashboard = new TravellerDashboard();
            this.Hide();
            tripDashboard.Show();
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            if (PaymentData.CurrentBooking != null)
            {
                textBox2.Text = PaymentData.CurrentBooking.BookingId.ToString();
                textBox1.Text = PaymentData.CurrentBooking.Amount.ToString("C");
            }
            else
            {
                MessageBox.Show("No booking data found.");
                this.Close();
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
