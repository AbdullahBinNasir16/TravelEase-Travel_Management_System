﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class CreateTrip : Form
    {
        public CreateTrip()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e) // Create button
        {
            // Validate required fields
            if (string.IsNullOrWhiteSpace(textBox2.Text) || // Title
                string.IsNullOrWhiteSpace(textBox4.Text) || // Location
                string.IsNullOrWhiteSpace(textBox5.Text))   // Price
            {
                MessageBox.Show("Please fill in all required fields (Title, Location, Price)");
                return;
            }

            try
            {
                // Get values from form controls
                string title = textBox2.Text;
                string description = textBox1.Text;
                string location = textBox4.Text;
                string category = textBox6.Text;
                decimal price = decimal.Parse(textBox5.Text);
                DateTime startDate = dateTimePicker2.Value;
                DateTime endDate = dateTimePicker1.Value;
                string notes = textBox9.Text;
                string status = "Available"; // Default status

                // Insert into database
                string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";
                string query = @"
                    INSERT INTO Trip 
                    (title, description, location, category, price, 
                     start_date, end_date, notes, status)
                    VALUES 
                    (@title, @description, @location, @category, @price, 
                     @startDate, @endDate, @notes, @status)";

                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@description", string.IsNullOrEmpty(description) ? (object)DBNull.Value : description);
                    cmd.Parameters.AddWithValue("@location", location);
                    cmd.Parameters.AddWithValue("@category", string.IsNullOrEmpty(category) ? (object)DBNull.Value : category);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@startDate", startDate);
                    cmd.Parameters.AddWithValue("@endDate", endDate);
                    cmd.Parameters.AddWithValue("@notes", string.IsNullOrEmpty(notes) ? (object)DBNull.Value : notes);
                    cmd.Parameters.AddWithValue("@status", status);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Trip created successfully!");
                        this.Close(); // Close form after successful creation
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid price (numbers only)");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating trip: {ex.Message}");
            }
        }

        private void CreateTrip_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
