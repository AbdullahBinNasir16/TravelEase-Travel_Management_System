﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TravellerDashboard travellerDashboard = new TravellerDashboard();
            this.Hide();
            travellerDashboard.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a booking to proceed to payment.");
                return;
            }

            // Get selected booking details
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int bookingId = Convert.ToInt32(selectedRow.Cells["Booking ID"].Value);
            decimal amount = Convert.ToDecimal(selectedRow.Cells["Amount"].Value);

            // Pass data to payment form using static class
            PaymentData.CurrentBooking = new BookingData
            {
                BookingId = bookingId,
                Amount = amount
            };

            Payment payment = new Payment();
            this.Hide();
            payment.Show();
        }

        private void Booking_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";
            string query = @"
            SELECT 
                b.booking_id AS 'Booking ID',
                t.title AS 'Trip',
                t.price AS 'Amount',
                b.booking_date AS 'Booking Date',
                b.status AS 'Status'
            FROM Booking b
            JOIN Trip t ON b.trip_id = t.trip_id
            WHERE b.traveler_id = @userId
            ORDER BY b.booking_date DESC";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.SelectCommand.Parameters.AddWithValue("@userId", UserSession.TravelerId);

                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Configure DataGridView
                dataGridView1.DataSource = dt;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.ReadOnly = true;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
   
            }
        }
    }
}
