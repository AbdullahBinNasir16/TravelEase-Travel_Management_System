﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Wishlist : Form
    {
        public Wishlist()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            TravellerDashboard travellerDashboard = new TravellerDashboard();
            this.Hide();
            travellerDashboard.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a trip first.");
                return;
            }

            int tripId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["trip_id"].Value);
            int travelerId = UserSession.TravelerId;
            decimal price = Convert.ToDecimal(dataGridView1.SelectedRows[0].Cells["price"].Value);

            try
            {
                string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Insert into Bookings table
                    string insertQuery = @"
                INSERT INTO Booking 
                (trip_id, traveler_id, booking_date, travelers_count, total_cost, status)
                VALUES 
                (@trip_id, @traveler_id, GETDATE(), 1, @price, 'Pending')";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@trip_id", tripId);
                        cmd.Parameters.AddWithValue("@traveler_id", travelerId);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.ExecuteNonQuery();
                    }

                    // Open Booking page with the trip ID
                    Booking bookingForm = new Booking();
                    this.Hide();
                    bookingForm.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating booking: {ex.Message}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a trip to remove.");
                return;
            }

            int tripId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["trip_id"].Value);
            int travelerId = UserSession.TravelerId;

            if (MessageBox.Show("Remove this trip from your wishlist?", "Confirm Removal",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";
                    string query = "DELETE FROM Wishlist WHERE traveler_id = @traveler_id AND trip_id = @trip_id";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@traveler_id", travelerId);
                        cmd.Parameters.AddWithValue("@trip_id", tripId);

                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        conn.Close();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Trip removed from wishlist.");
                            Wishlist_Load(sender, e); 
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error removing trip: {ex.Message}");
                }
            }
        }

        private void Wishlist_Load(object sender, EventArgs e)
        {
            int travelerId = UserSession.TravelerId;

            string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";
            string query = @"
        SELECT T.trip_id, T.title, T.location, T.category, T.price, T.duration, 
               T.start_date, T.end_date, T.rating
        FROM Wishlist W
        JOIN Trip T ON W.trip_id = T.trip_id
        WHERE W.traveler_id = @traveler_id";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@traveler_id", travelerId);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;

                // Optional: Hide trip_id
                dataGridView1.Columns["trip_id"].Visible = false;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
