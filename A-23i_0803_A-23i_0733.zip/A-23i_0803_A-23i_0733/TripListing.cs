﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class TripListing : Form
    {
        public TripListing()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Columns["TripId"].Visible = false;
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Columns["TripId"].Visible = false;
        }
        private void TripListing_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";
            string query = "SELECT trip_id, title, location, category, price, duration, start_date, end_date, rating FROM Trip WHERE status = 'Available'";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;

                // Optional: Hide trip_id if you want
                dataGridView1.Columns["trip_id"].Visible = false;
            }
        }

        private int GetLoggedInTravelerId()
        {
            return UserSession.TravelerId;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int tripId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["trip_id"].Value);
                int travelerId = GetLoggedInTravelerId();

                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True"))
                {
                    // Check if it's already in the wishlist
                    string checkQuery = "SELECT COUNT(*) FROM Wishlist WHERE traveler_id = @traveler_id AND trip_id = @trip_id";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@traveler_id", travelerId);
                    checkCmd.Parameters.AddWithValue("@trip_id", tripId);

                    conn.Open();
                    int exists = (int)checkCmd.ExecuteScalar();
                    conn.Close();

                    if (exists > 0)
                    {
                        MessageBox.Show("This trip is already in your wishlist.");
                        return;
                    }

                    // Insert into wishlist
                    string insertQuery = "INSERT INTO Wishlist (traveler_id, trip_id) VALUES (@traveler_id, @trip_id)";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
                    insertCmd.Parameters.AddWithValue("@traveler_id", travelerId);
                    insertCmd.Parameters.AddWithValue("@trip_id", tripId);

                    conn.Open();
                    insertCmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Trip added to your wishlist!");
                    Wishlist wishlist = new Wishlist();
                    this.Hide();
                    wishlist.Show();  
                }
            }
            else
            {
                MessageBox.Show("Please select a trip first.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a trip first.");
                return;
            }

            int tripId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["trip_id"].Value);
            int travelerId = UserSession.TravelerId;
            decimal price = Convert.ToDecimal(dataGridView1.SelectedRows[0].Cells["price"].Value);

            try
            {
                string connectionString = "Data Source=DESKTOP-AFS1KNC\\SQLEXPRESS;Initial Catalog=TravelEase2;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Insert into Bookings table
                    string insertQuery = @"
                INSERT INTO Booking 
                (trip_id, traveler_id, booking_date, travelers_count, total_cost, status)
                VALUES 
                (@trip_id, @traveler_id, GETDATE(), 1, @price, 'Pending')";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@trip_id", tripId);
                        cmd.Parameters.AddWithValue("@traveler_id", travelerId);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.ExecuteNonQuery();
                    }

                    // Open Booking page with the trip ID
                    Booking bookingForm = new Booking();
                    this.Hide();
                    bookingForm.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating booking: {ex.Message}");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TravellerDashboard travellerDashboard = new TravellerDashboard();
            this.Hide();
            travellerDashboard.Show();
        }

        
    }
}
