﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class UserSession
    {
        public static int TravelerId { get; set; }
    }
    public static class PaymentData
    {
        public static BookingData CurrentBooking { get; set; }
    }

    public class BookingData
    {
        public int BookingId { get; set; }
        public decimal Amount { get; set; }
    }

    public static class OperatorID
    {
        public static int OperId { get; set; }
    }

    public static class AdminID
    {
        public static int admId { get; set; }
    }
}
