﻿create database TravelEase
use TravelEase
-- Create Tables
CREATE TABLE TourOperator (
    operator_id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(50),
    phone VARCHAR(15),
    description TEXT,
    status VARCHAR(20)
);

CREATE TABLE Admin (
    admin_id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(50),
    role VARCHAR(50)
);

CREATE TABLE Trip (
    trip_id INT PRIMARY KEY,
    operator_id INT,
    title VARCHAR(100),
    description TEXT,
    location VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2),
    duration INT,
    capacity INT,
    start_date DATE,
    end_date DATE,
    notes TEXT,
    rating INT,
    status VARCHAR(20),
    FOREIGN KEY (operator_id) REFERENCES TourOperator(operator_id)
);

CREATE TABLE Booking (
    booking_id INT PRIMARY KEY,
    trip_id INT,
    traveler_id INT,
    booking_date DATE,
    travelers_count INT,
    total_cost DECIMAL(10,2),
    status VARCHAR(20),
    FOREIGN KEY (trip_id) REFERENCES Trip(trip_id)
);

CREATE TABLE Payment (
    payment_id INT PRIMARY KEY,
    booking_id INT,
    amount DECIMAL(10,2),
    payment_date DATE,
    method VARCHAR(50),
    status VARCHAR(20),
    is_refunded bit,
    is_fraud bit,
    FOREIGN KEY (booking_id) REFERENCES Booking(booking_id)
);

CREATE TABLE Review (
    review_id INT PRIMARY KEY,
    trip_id INT,
    traveler_id INT,
    rating INT,
    comment TEXT,
    review_date DATE,
    FOREIGN KEY (trip_id) REFERENCES Trip(trip_id)
);

CREATE TABLE Hotel (
    hotel_id INT PRIMARY KEY,
    name VARCHAR(100),
    location VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(15),
    rooms INT,
    availability_status VARCHAR(20),
    status VARCHAR(20)
);

CREATE TABLE ServiceProvider (
    provider_id INT PRIMARY KEY,
    name VARCHAR(100),
    type VARCHAR(50),
    email VARCHAR(100),
    status VARCHAR(20)
);

CREATE TABLE TripServiceAssignment (
    assignment_id INT PRIMARY KEY,
    trip_id INT,
    hotel_id INT,
    guide_id INT,
    transport_id INT,
    status VARCHAR(20),
    FOREIGN KEY (trip_id) REFERENCES Trip(trip_id),
    FOREIGN KEY (hotel_id) REFERENCES Hotel(hotel_id),
    FOREIGN KEY (guide_id) REFERENCES ServiceProvider(provider_id),
    FOREIGN KEY (transport_id) REFERENCES ServiceProvider(provider_id)
);

CREATE TABLE Wishlist (
    wishlist_id INT PRIMARY KEY,
    traveler_id INT,
    trip_id INT
);

-- Insert Records
INSERT INTO TourOperator VALUES
(1, 'WanderKids', 'mehreen@wanderkids.nu.edu.pk', 'bubblegum123', '04200011122', 'We go where your FAST friends won’t let you 😜', 'Approved'),
(2, 'TacoTravellers', 'talha@tacotravellers.nu.edu.pk', 'spicyNuggets', '04212345678', 'Warning: Too much adventure causes giggles 🌮', 'Approved'),
(3, 'GiggleExpress', 'shahzaib@giggles.nu.edu.pk', 'gigglePower', '04287654321', 'Certified fun by FAST Cafeteria', 'Pending');

INSERT INTO Admin VALUES
(1, 'Mama Admin', 'admin@travelease.com', 'noCookies!', 'SuperAdmin'),
(2, 'Professor Ninja', 'ninja@nu.edu.pk', 'katanaSharp', 'GodMode'),
(3, 'Sleepy Sir', 'sleepy@nu.edu.pk', 'snorlax', 'BackupAdmin');

INSERT INTO Trip VALUES
(1, 1, 'Bubble Mountains', 'Hop snowy peaks ❄', 'Fairy Meadows', 'Adventure', 30000.00, 3, 10, '2025-07-10', '2025-07-12', 'Hops allowed', 4, 'Active'),
(2, 2, 'Curry Quest', 'Chase like Sherlock Holmes 🕵‍♂', 'Lahore', 'Cultural', 15000.00, 2, 8, '2025-08-01', '2025-08-02', 'Nose protection needed', 3, 'Active'),
(3, 1, 'Sleepy Safari', 'Safari with naps every ghanta 🦓', 'Cholistan Desert', 'Leisure', 20000.00, 2, 12, '2025-09-05', '2025-09-06', 'Blankets included', 5, 'Active');

INSERT INTO Booking VALUES
(1, 1, 1, '2025-06-01', 2, 60000.00, 'Confirmed'),
(2, 2, 2, '2025-07-25', 1, 15000.00, 'Pending'),
(3, 3, 3, '2025-08-30', 3, 60000.00, 'Confirmed');

INSERT INTO Payment VALUES
(1, 1, 60000.00, '2025-06-01', 'BubbleCard', 'Success', 0, 0),
(2, 2, 15000.00, '2025-07-25', 'PocketMoney', 'Failed', 1, 1),
(3, 3, 60000.00, '2025-08-30', 'ToyCoins', 'Success', 0, 0);

INSERT INTO Review VALUES
(1, 1, 1, 5, 'Fluffy clouds and snowball fights! 🌨😂', '2025-06-05'),
(2, 2, 2, 4, 'So spicy, even my laptop cried 🌶😭', '2025-08-03'),
(3, 3, 3, 5, 'Camel photobombed my selfie 🐫📸', '2025-09-07');

INSERT INTO Hotel VALUES
(1, 'Snuggle Inn', 'Fairy Meadows', 'roomz@snuggleinn.nu.edu.pk', '05821441234', 15, 'Available', 'Active'),
(2, 'Spice Palace', 'Lahore', 'flames@spicepalace.nu.edu.pk', '0425554444', 25, 'Booked', 'Active'),
(3, 'Nap House', 'Cholistan', 'shhhh@naphouse.nu.edu.pk', '03003332211', 20, 'Available', 'Active');

INSERT INTO ServiceProvider VALUES
(1, 'Tina Toots', 'Tour Guide', 'toots@guide.nu.edu.pk', 'Available'),
(2, 'Bobby Snacks', 'Chef', 'snacks@chef.nu.edu.pk', 'Available'),
(3, 'Zuzu Van', 'Transport', 'drive@zuzu.nu.edu.pk', 'Unavailable');

INSERT INTO TripServiceAssignment VALUES
(1, 1, 1, 1, 1, 'Confirmed'),
(2, 2, 2, 2, 2, 'Pending'),
(3, 3, 3, 3, 3, 'Confirmed');

INSERT INTO Wishlist VALUES
(1, 1, 2),
(2, 2, 1),
(3, 3, 3);